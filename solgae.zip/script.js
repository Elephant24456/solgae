window.onload = function() {
    const startButton = document.getElementById("start");
    startButton.onclick = startQuiz;
}

const answers = {};

async function startQuiz() {
    const quizDiv = document.getElementById("quiz");
    quizDiv.innerHTML = "";

    const response = await fetch('http://localhost:3000/ask', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prompt: "피부 타입을 판별하는데 도움이 되는 질문 25개를 생성해주세요." })
    });
    const questions = await response.json();

    for (const question of questions) {
        const p = document.createElement("p");
        p.textContent = question;
        quizDiv.appendChild(p);

        const yesButton = document.createElement("button");
        yesButton.textContent = "예";
        yesButton.onclick = function() { handleAnswer(question, "예"); };
        quizDiv.appendChild(yesButton);

        const noButton = document.createElement("button");
        noButton.textContent = "아니오";
        noButton.onclick = function() { handleAnswer(question, "아니오"); };
        quizDiv.appendChild(noButton);
    }

    const resultButton = document.createElement("button");
    resultButton.textContent = "결과 보기";
    resultButton.onclick = determineSkinType;
    quizDiv.appendChild(resultButton);
}

function handleAnswer(question, answer) {
    answers[question] = answer;
}

function determineSkinType() {
    const skinTypes = ["지성", "중성", "민감성", "복합성", "건성"];
    const scores = { "지성": 0, "중성": 0, "민감성": 0, "복합성": 0, "건성": 0 };

    for (const question in answers) {
        const answer = answers[question];
        if (answer && answer.toLowerCase() == "예") {
            const type = skinTypes[Math.floor(Math.random() * skinTypes.length)];
            scores[type]++;
        }
    }

    let maxScore = 0;
    let resultType = null;
    for (const type in scores) {
        if (scores[type] > maxScore) {
            maxScore = scores[type];
            resultType = type;
        }
    }

    let result = "당신의 피부 타입은 " + resultType + "입니다.";
    document.getElementById("result").innerHTML = result;
}
