const express = require('express');
const openai = require('openai');

openai.apiKey = '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';

const app = express();
app.use(express.json());

app.post('/ask', async (req, res) => {
    const prompt = req.body.prompt;
    const response = await openai.Completion.create({
        engine: 'text-davinci-002',
        prompt: prompt,
        temperature: 0.5,
        max_tokens: 60
    });

    res.send(response.choices[0].text);
});

app.listen(3000, () => console.log('Server listening on port 3000'));